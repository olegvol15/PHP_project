<h1>Contacts Us</h1>

<?php
    Messages::getMessage();
?>

<form action="/contacts" method="post">

    <div class="form-group mt-3">
        <label for="name">Name: </label>
        <input type="text" name="name" class="form-control">
    </div>

    <div class="form-group mt-3">
        <label for="email">Email: </label>
        <input type="email" name="email" class="form-control">
    </div>

    <div class="form-group mt-3">
        <label for="message">Message: </label>
        <textarea name="message" class="form-control"></textarea>
    </div>

    <button class="btn btn-primary mt-3" name="action" value="sendMail">Send</button>
</form>
