<?php
session_start();
require_once "functions/Messages.php";

$action = $_POST['action'] ?? null; // 'sendMail'
if(!empty($action)){
    $action(); // sendMail()
}

function redirect($url){
    header("Location: $url");
    exit;
}


function sendMail(){
    $name = $_POST['name'] ?? '';
    $email = $_POST['email'] ?? '';
    $message = $_POST['message'] ?? '';

    if(empty($name) || empty($email) || empty($message)){
        Messages::setMessage("All fields are required", 'danger');
        redirect("/contacts");
    }
    
    Messages::setMessage("Message sent successfully");

    redirect("/contacts");
}

